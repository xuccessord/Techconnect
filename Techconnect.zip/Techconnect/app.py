from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from datetime import timedelta
from functools import wraps
import os

app = Flask(__name__)

app.secret_key = "techconnect-development-secret-key"
app.permanent_session_lifetime = timedelta(days=7)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE_DIR, "techconnect.db")


# =========================================================
# DATABASE
# =========================================================

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():

    conn = get_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT,
            password TEXT NOT NULL,
            account_type TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS user_categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            category TEXT NOT NULL,
            FOREIGN KEY (user_id)
                REFERENCES users(id)
                ON DELETE CASCADE
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS professional_profiles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE NOT NULL,
            professional_title TEXT,
            bio TEXT,
            hourly_rate REAL,
            location TEXT,
            availability TEXT DEFAULT 'available',
            experience TEXT,
            education TEXT,
            certifications TEXT,
            services TEXT,
            languages TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id)
                REFERENCES users(id)
                ON DELETE CASCADE
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            experience_level TEXT DEFAULT 'any',
            budget_type TEXT DEFAULT 'fixed',
            budget_min REAL NOT NULL,
            budget_max REAL NOT NULL,
            deadline TEXT,
            status TEXT DEFAULT 'open',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (client_id)
                REFERENCES users(id)
                ON DELETE CASCADE
        )
    """)
    conn.execute("""
    CREATE TABLE IF NOT EXISTS milestones (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        amount REAL NOT NULL,
        due_date TEXT,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id)
            REFERENCES projects(id)
            ON DELETE CASCADE
    )
""")

    conn.execute("""
    CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        milestone_id INTEGER,
        payer_id INTEGER NOT NULL,
        receiver_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        status TEXT DEFAULT 'pending',
        payment_reference TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id)
            REFERENCES projects(id)
            ON DELETE CASCADE,
        FOREIGN KEY (milestone_id)
            REFERENCES milestones(id)
            ON DELETE SET NULL,
        FOREIGN KEY (payer_id)
            REFERENCES users(id)
            ON DELETE CASCADE,
        FOREIGN KEY (receiver_id)
            REFERENCES users(id)
            ON DELETE CASCADE
            )
        """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS proposals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            professional_id INTEGER NOT NULL,
            proposed_amount REAL NOT NULL,
            delivery_days INTEGER,
            message TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id)
                REFERENCES projects(id)
                ON DELETE CASCADE,
            FOREIGN KEY (professional_id)
                REFERENCES users(id)
                ON DELETE CASCADE,
            UNIQUE(project_id, professional_id)
        )
    """)

    conn.execute("""
    CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        reviewer_id INTEGER NOT NULL,
        reviewee_id INTEGER NOT NULL,
        rating INTEGER NOT NULL,
        review TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (project_id)
            REFERENCES projects(id)
            ON DELETE CASCADE,

        FOREIGN KEY (reviewer_id)
            REFERENCES users(id)
            ON DELETE CASCADE,

        FOREIGN KEY (reviewee_id)
            REFERENCES users(id)
            ON DELETE CASCADE,

        UNIQUE(project_id, reviewer_id)
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            sender_id INTEGER NOT NULL,
            receiver_id INTEGER NOT NULL,
            message TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_read INTEGER DEFAULT 0,
            FOREIGN KEY (project_id)
                REFERENCES projects(id)
                ON DELETE CASCADE,
            FOREIGN KEY (sender_id)
                REFERENCES users(id)
                ON DELETE CASCADE,
            FOREIGN KEY (receiver_id)
                REFERENCES users(id)
                ON DELETE CASCADE
        )
    """)

    

    conn.commit()
    conn.close()


# =========================================================
# LOGIN REQUIRED
# =========================================================

def login_required(view):

    @wraps(view)
    def wrapped_view(*args, **kwargs):

        if "user_id" not in session:
            return redirect(url_for("login"))

        return view(*args, **kwargs)

    return wrapped_view


# =========================================================
# HOME
# =========================================================

@app.route("/")
def index():
    return render_template("index.html")


# =========================================================
# REGISTER
# =========================================================

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        full_name = request.form.get(
            "full_name",
            ""
        ).strip()

        email = request.form.get(
            "email",
            ""
        ).strip().lower()

        phone = request.form.get(
            "phone",
            ""
        ).strip()

        password = request.form.get(
            "password",
            ""
        )

        account_type = request.form.get(
            "account_type",
            ""
        ).strip().lower()

        categories = request.form.getlist("categories")

        if not categories:

            category = request.form.get(
                "category",
                ""
            ).strip().lower()

            if category:
                categories = [category]

        valid_account_types = [
            "professional",
            "hire",
            "both"
        ]

        valid_categories = [
            "aws",
            "networking",
            "cyber security",
            "web development"
        ]

        if not full_name or not email or not password:

            flash(
                "Please complete all required fields.",
                "error"
            )

            return redirect(url_for("register"))

        if account_type not in valid_account_types:

            flash(
                "Please select a valid account type.",
                "error"
            )

            return redirect(url_for("register"))

        categories = [
            category.lower()
            for category in categories
            if category.lower() in valid_categories
        ]

        if not categories:

            flash(
                "Please select at least one technology category.",
                "error"
            )

            return redirect(url_for("register"))

        conn = get_db()

        try:

            existing_user = conn.execute("""
                SELECT id
                FROM users
                WHERE email = ?
            """, (email,)).fetchone()

            if existing_user:

                flash(
                    "An account with this email already exists.",
                    "error"
                )

                return redirect(url_for("register"))

            cursor = conn.execute("""
                INSERT INTO users (
                    full_name,
                    email,
                    phone,
                    password,
                    account_type
                )
                VALUES (?, ?, ?, ?, ?)
            """, (
                full_name,
                email,
                phone,
                password,
                account_type
            ))

            user_id = cursor.lastrowid

            for category in categories:

                conn.execute("""
                    INSERT INTO user_categories (
                        user_id,
                        category
                    )
                    VALUES (?, ?)
                """, (
                    user_id,
                    category
                ))

            if account_type in [
                "professional",
                "both"
            ]:

                conn.execute("""
                    INSERT OR IGNORE INTO professional_profiles (
                        user_id
                    )
                    VALUES (?)
                """, (
                    user_id,
                ))

            conn.commit()

            flash(
                "Account created successfully. Please log in.",
                "success"
            )

            return redirect(url_for("login"))

        except sqlite3.IntegrityError:

            conn.rollback()

            flash(
                "That email is already registered.",
                "error"
            )

            return redirect(url_for("register"))

        except sqlite3.Error as e:

            conn.rollback()

            print("REGISTER DATABASE ERROR:", e)

            flash(
                "There was a problem creating your account.",
                "error"
            )

            return redirect(url_for("register"))

        finally:

            conn.close()

    return render_template("register.html")


# =========================================================
# MILESTONES
# =========================================================

@app.route(
    "/project/<int:project_id>/milestones",
    methods=["GET", "POST"]
)
@login_required
def project_milestones(project_id):

    user_id = session["user_id"]

    conn = get_db()

    try:

        workspace = conn.execute("""
            SELECT
                projects.id AS project_id,
                projects.title,
                projects.client_id,
                proposals.professional_id,
                proposals.proposed_amount
            FROM projects
            JOIN proposals
                ON proposals.project_id = projects.id
            WHERE projects.id = ?
            AND proposals.status = 'accepted'
            AND (
                projects.client_id = ?
                OR proposals.professional_id = ?
            )
            LIMIT 1
        """, (
            project_id,
            user_id,
            user_id
        )).fetchone()

        if not workspace:

            flash(
                "You do not have access to this project's milestones.",
                "error"
            )

            return redirect(url_for("dashboard"))

        if request.method == "POST":

            if user_id != workspace["client_id"]:

                flash(
                    "Only the project owner can create milestones.",
                    "error"
                )

                return redirect(
                    url_for(
                        "project_milestones",
                        project_id=project_id
                    )
                )

            title = request.form.get(
                "title",
                ""
            ).strip()

            description = request.form.get(
                "description",
                ""
            ).strip()

            amount = request.form.get(
                "amount",
                ""
            ).strip()

            due_date = request.form.get(
                "due_date",
                ""
            ).strip()

            if not title or not amount:

                flash(
                    "Milestone title and amount are required.",
                    "error"
                )

                return redirect(
                    url_for(
                        "project_milestones",
                        project_id=project_id
                    )
                )

            try:

                amount_value = float(amount)

                if amount_value <= 0:

                    raise ValueError

            except ValueError:

                flash(
                    "Please enter a valid milestone amount.",
                    "error"
                )

                return redirect(
                    url_for(
                        "project_milestones",
                        project_id=project_id
                    )
                )

            conn.execute("""
                INSERT INTO milestones (
                    project_id,
                    title,
                    description,
                    amount,
                    due_date
                )
                VALUES (?, ?, ?, ?, ?)
            """, (
                project_id,
                title,
                description,
                amount_value,
                due_date
            ))

            conn.commit()

            flash(
                "Milestone created successfully.",
                "success"
            )

            return redirect(
                url_for(
                    "project_milestones",
                    project_id=project_id
                )
            )

        milestones = conn.execute("""
            SELECT *
            FROM milestones
            WHERE project_id = ?
            ORDER BY id ASC
        """, (
            project_id,
        )).fetchall()

        total_amount = sum(
            milestone["amount"]
            for milestone in milestones
        )

        completed_amount = sum(
            milestone["amount"]
            for milestone in milestones
            if milestone["status"] == "completed"
        )

        return render_template(
            "milestones.html",
            workspace=workspace,
            milestones=milestones,
            total_amount=total_amount,
            completed_amount=completed_amount
        )

    except sqlite3.Error as e:

        conn.rollback()

        print(
            "MILESTONE DATABASE ERROR:",
            e
        )

        flash(
            "There was a problem loading the milestones.",
            "error"
        )

        return redirect(
            url_for(
                "project_workspace",
                project_id=project_id
            )
        )

    finally:

        conn.close()


# =========================================================
# UPDATE MILESTONE
# =========================================================

@app.route(
    "/project/<int:project_id>/milestones/<int:milestone_id>/status",
    methods=["POST"]
)
@login_required
def update_milestone_status(
    project_id,
    milestone_id
):

    user_id = session["user_id"]

    conn = get_db()

    try:

        workspace = conn.execute("""
            SELECT
                projects.client_id,
                proposals.professional_id
            FROM projects
            JOIN proposals
                ON proposals.project_id = projects.id
            WHERE projects.id = ?
            AND proposals.status = 'accepted'
            AND (
                projects.client_id = ?
                OR proposals.professional_id = ?
            )
            LIMIT 1
        """, (
            project_id,
            user_id,
            user_id
        )).fetchone()

        if not workspace:

            flash(
                "You do not have access to this project.",
                "error"
            )

            return redirect(url_for("dashboard"))

        milestone = conn.execute("""
            SELECT *
            FROM milestones
            WHERE id = ?
            AND project_id = ?
        """, (
            milestone_id,
            project_id
        )).fetchone()

        if not milestone:

            flash(
                "Milestone not found.",
                "error"
            )

            return redirect(
                url_for(
                    "project_milestones",
                    project_id=project_id
                )
            )

        new_status = request.form.get(
            "status",
            ""
        ).strip()

        allowed_statuses = [
            "pending",
            "in_progress",
            "submitted",
            "completed"
        ]

        if new_status not in allowed_statuses:

            flash(
                "Invalid milestone status.",
                "error"
            )

            return redirect(
                url_for(
                    "project_milestones",
                    project_id=project_id
                )
            )

        conn.execute("""
            UPDATE milestones

            SET status = ?,
                updated_at = CURRENT_TIMESTAMP

            WHERE id = ?
            AND project_id = ?
        """, (
            new_status,
            milestone_id,
            project_id
        ))

        conn.commit()

        flash(
            "Milestone status updated.",
            "success"
        )

        return redirect(
            url_for(
                "project_milestones",
                project_id=project_id
            )
        )

    except sqlite3.Error as e:

        conn.rollback()

        print(
            "MILESTONE STATUS ERROR:",
            e
        )

        flash(
            "There was a problem updating the milestone.",
            "error"
        )

        return redirect(
            url_for(
                "project_milestones",
                project_id=project_id
            )
        )

    finally:

        conn.close()


# =========================================================
# PAYMENTS
# =========================================================

@app.route(
    "/project/<int:project_id>/payments"
)
@login_required
def project_payments(project_id):

    user_id = session["user_id"]

    conn = get_db()

    try:

        workspace = conn.execute("""
            SELECT
                projects.id AS project_id,
                projects.title,
                projects.client_id,
                proposals.professional_id
            FROM projects
            JOIN proposals
                ON proposals.project_id = projects.id
            WHERE projects.id = ?
            AND proposals.status = 'accepted'
            AND (
                projects.client_id = ?
                OR proposals.professional_id = ?
            )
            LIMIT 1
        """, (
            project_id,
            user_id,
            user_id
        )).fetchone()

        if not workspace:

            flash(
                "You do not have access to this project's payments.",
                "error"
            )

            return redirect(url_for("dashboard"))

        payments = conn.execute("""
            SELECT
                payments.*,

                milestones.title AS milestone_title,

                payer.full_name AS payer_name,

                receiver.full_name AS receiver_name

            FROM payments

            LEFT JOIN milestones
                ON payments.milestone_id = milestones.id

            JOIN users AS payer
                ON payments.payer_id = payer.id

            JOIN users AS receiver
                ON payments.receiver_id = receiver.id

            WHERE payments.project_id = ?

            ORDER BY payments.created_at DESC

        """, (
            project_id,
        )).fetchall()

        milestones = conn.execute("""
            SELECT *
            FROM milestones
            WHERE project_id = ?
            ORDER BY id ASC
        """, (
            project_id,
        )).fetchall()

        total_paid = conn.execute("""
            SELECT COALESCE(
                SUM(amount),
                0
            )
            FROM payments
            WHERE project_id = ?
            AND status = 'paid'
        """, (
            project_id,
        )).fetchone()[0]

        total_pending = conn.execute("""
            SELECT COALESCE(
                SUM(amount),
                0
            )
            FROM payments
            WHERE project_id = ?
            AND status = 'pending'
        """, (
            project_id,
        )).fetchone()[0]

        return render_template(
            "payments.html",
            workspace=workspace,
            payments=payments,
            milestones=milestones,
            total_paid=total_paid,
            total_pending=total_pending
        )

    except sqlite3.Error as e:

        print(
            "PAYMENT DATABASE ERROR:",
            e
        )

        flash(
            "There was a problem loading payments.",
            "error"
        )

        return redirect(
            url_for(
                "project_workspace",
                project_id=project_id
            )
        )

    finally:

        conn.close()


# =========================================================
# CREATE PAYMENT
# =========================================================

@app.route(
    "/project/<int:project_id>/payments/create/<int:milestone_id>",
    methods=["POST"]
)
@login_required
def create_payment(
    project_id,
    milestone_id
):

    user_id = session["user_id"]

    conn = get_db()

    try:

        workspace = conn.execute("""
            SELECT
                projects.client_id,
                proposals.professional_id
            FROM projects

            JOIN proposals
                ON proposals.project_id = projects.id

            WHERE projects.id = ?

            AND proposals.status = 'accepted'

            AND projects.client_id = ?

            LIMIT 1
        """, (
            project_id,
            user_id
        )).fetchone()

        if not workspace:

            flash(
                "Only the project owner can create payments.",
                "error"
            )

            return redirect(
                url_for(
                    "project_payments",
                    project_id=project_id
                )
            )

        milestone = conn.execute("""
            SELECT *
            FROM milestones
            WHERE id = ?
            AND project_id = ?
        """, (
            milestone_id,
            project_id
        )).fetchone()

        if not milestone:

            flash(
                "Milestone not found.",
                "error"
            )

            return redirect(
                url_for(
                    "project_payments",
                    project_id=project_id
                )
            )

        existing_payment = conn.execute("""
            SELECT id
            FROM payments
            WHERE project_id = ?
            AND milestone_id = ?
            AND status IN (
                'pending',
                'paid'
            )
            LIMIT 1
        """, (
            project_id,
            milestone_id
        )).fetchone()

        if existing_payment:

            flash(
                "A payment already exists for this milestone.",
                "error"
            )

            return redirect(
                url_for(
                    "project_payments",
                    project_id=project_id
                )
            )

        conn.execute("""
            INSERT INTO payments (
                project_id,
                milestone_id,
                payer_id,
                receiver_id,
                amount,
                status,
                payment_reference
            )
            VALUES (?, ?, ?, ?, ?, 'pending', ?)
        """, (
            project_id,
            milestone_id,
            workspace["client_id"],
            workspace["professional_id"],
            milestone["amount"],
            f"TC-{project_id}-{milestone_id}"
        ))

        conn.commit()

        flash(
            "Payment created successfully.",
            "success"
        )

        return redirect(
            url_for(
                "project_payments",
                project_id=project_id
            )
        )

    except sqlite3.Error as e:

        conn.rollback()

        print(
            "CREATE PAYMENT ERROR:",
            e
        )

        flash(
            "There was a problem creating the payment.",
            "error"
        )

        return redirect(
            url_for(
                "project_payments",
                project_id=project_id
            )
        )

    finally:

        conn.close()


# =========================================================
# MARK PAYMENT AS PAID
# =========================================================

@app.route(
    "/project/<int:project_id>/payments/<int:payment_id>/pay",
    methods=["POST"]
)
@login_required
def mark_payment_paid(
    project_id,
    payment_id
):

    user_id = session["user_id"]

    conn = get_db()

    try:

        payment = conn.execute("""
            SELECT
                payments.*,
                projects.client_id
            FROM payments

            JOIN projects
                ON payments.project_id = projects.id

            WHERE payments.id = ?

            AND payments.project_id = ?

        """, (
            payment_id,
            project_id
        )).fetchone()

        if not payment:

            flash(
                "Payment not found.",
                "error"
            )

            return redirect(
                url_for(
                    "project_payments",
                    project_id=project_id
                )
            )

        if payment["client_id"] != user_id:

            flash(
                "Only the project owner can process this payment.",
                "error"
            )

            return redirect(
                url_for(
                    "project_payments",
                    project_id=project_id
                )
            )

        if payment["status"] != "pending":

            flash(
                "This payment has already been processed.",
                "error"
            )

            return redirect(
                url_for(
                    "project_payments",
                    project_id=project_id
                )
            )

        conn.execute("""
            UPDATE payments

            SET status = 'paid',
                updated_at = CURRENT_TIMESTAMP

            WHERE id = ?

            AND project_id = ?

        """, (
            payment_id,
            project_id
        ))

        conn.commit()

        flash(
            "Payment marked as paid.",
            "success"
        )

        return redirect(
            url_for(
                "project_payments",
                project_id=project_id
            )
        )

    except sqlite3.Error as e:

        conn.rollback()

        print(
            "PAYMENT UPDATE ERROR:",
            e
        )

        flash(
            "There was a problem processing the payment.",
            "error"
        )

        return redirect(
            url_for(
                "project_payments",
                project_id=project_id
            )
        )

    finally:

        conn.close()


# =========================================================
# LOGIN
# =========================================================

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form.get(
            "email",
            ""
        ).strip().lower()

        password = request.form.get(
            "password",
            ""
        )

        conn = get_db()

        user = conn.execute("""
            SELECT *
            FROM users
            WHERE email = ?
            AND password = ?
        """, (
            email,
            password
        )).fetchone()

        conn.close()

        if not user:

            flash(
                "Invalid email or password.",
                "error"
            )

            return redirect(url_for("login"))

        session.permanent = True

        session["user_id"] = user["id"]
        session["user_name"] = user["full_name"]
        session["user_email"] = user["email"]
        session["account_type"] = user["account_type"]

        return redirect(url_for("dashboard"))

    return render_template("login.html")


# =========================================================
# LOGOUT
# =========================================================

@app.route("/logout")
def logout():

    session.clear()

    return redirect(
        url_for("login")
    )


# =========================================================
# DASHBOARD
# =========================================================

@app.route("/dashboard")
@login_required
def dashboard():

    user_id = session["user_id"]

    conn = get_db()

    user = conn.execute("""
        SELECT *
        FROM users
        WHERE id = ?
    """, (
        user_id,
    )).fetchone()

    professional_profile = conn.execute("""
        SELECT *
        FROM professional_profiles
        WHERE user_id = ?
    """, (
        user_id,
    )).fetchone()

    categories = conn.execute("""
        SELECT category
        FROM user_categories
        WHERE user_id = ?
        ORDER BY category
    """, (
        user_id,
    )).fetchall()

    profile_completion = 0

    if (
        user["account_type"]
        in ["professional", "both"]
        and professional_profile
    ):

        fields = [
            professional_profile["professional_title"],
            professional_profile["bio"],
            professional_profile["hourly_rate"],
            professional_profile["location"],
            professional_profile["experience"],
            professional_profile["education"],
            professional_profile["certifications"],
            professional_profile["services"],
            professional_profile["languages"]
        ]

        completed = sum(
            1
            for value in fields
            if value not in (None, "")
        )

        profile_completion = round(
            (completed / len(fields)) * 100
        )

    recent_projects = []
    recent_proposals = []

    projects_count = conn.execute("""
        SELECT COUNT(*)
        FROM projects
        WHERE client_id = ?
    """, (
        user_id,
    )).fetchone()[0]

    proposals_received = conn.execute("""
        SELECT COUNT(*)
        FROM proposals
        JOIN projects
            ON proposals.project_id = projects.id
        WHERE projects.client_id = ?
    """, (
        user_id,
    )).fetchone()[0]

    if user["account_type"] in ["hire", "both"]:

        recent_projects = conn.execute("""
            SELECT
                projects.id,
                projects.title,
                projects.category,
                projects.budget_type,
                projects.budget_min,
                projects.budget_max,
                projects.deadline,
                projects.status,
                projects.created_at,
                COUNT(proposals.id) AS proposal_count
            FROM projects
            LEFT JOIN proposals
                ON proposals.project_id = projects.id
            WHERE projects.client_id = ?
            GROUP BY projects.id
            ORDER BY projects.created_at DESC
            LIMIT 5
        """, (
            user_id,
        )).fetchall()

        recent_proposals = conn.execute("""
            SELECT
                proposals.id,
                proposals.project_id,
                proposals.proposed_amount,
                proposals.delivery_days,
                proposals.message,
                proposals.status,
                proposals.created_at,
                projects.title AS project_title,
                users.full_name AS professional_name
            FROM proposals
            JOIN projects
                ON proposals.project_id = projects.id
            JOIN users
                ON proposals.professional_id = users.id
            WHERE projects.client_id = ?
            ORDER BY proposals.created_at DESC
            LIMIT 5
        """, (
            user_id,
        )).fetchall()

    professional_proposals = []

    if user["account_type"] in [
        "professional",
        "both"
    ]:

        professional_proposals = conn.execute("""
            SELECT
                proposals.*,
                projects.title AS project_title,
                projects.category AS project_category,
                users.full_name AS client_name
            FROM proposals
            JOIN projects
                ON proposals.project_id = projects.id
            JOIN users
                ON projects.client_id = users.id
            WHERE proposals.professional_id = ?
            ORDER BY proposals.created_at DESC
            LIMIT 5
        """, (
            user_id,
        )).fetchall()

    conn.close()

    if user["account_type"] == "professional":

        return render_template(
            "professional_dashboard.html",
            user=user,
            categories=categories,
            professional_profile=professional_profile,
            profile_completion=profile_completion,
            professional_proposals=professional_proposals
        )

    if user["account_type"] == "hire":

        return render_template(
            "hire_dashboard.html",
            user=user,
            categories=categories,
            recent_projects=recent_projects,
            recent_proposals=recent_proposals,
            projects_count=projects_count,
            proposals_received=proposals_received
        )

    return render_template(
        "dashboard.html",
        user=user,
        categories=categories,
        professional_profile=professional_profile,
        profile_completion=profile_completion,
        recent_projects=recent_projects,
        recent_proposals=recent_proposals,
        professional_proposals=professional_proposals,
        projects_count=projects_count,
        proposals_received=proposals_received
    )


# =========================================================
# PROFESSIONAL MARKETPLACE
# =========================================================

@app.route("/professionals")
def professionals():

    category = request.args.get(
        "category",
        ""
    ).strip()

    search = request.args.get(
        "search",
        ""
    ).strip()

    conn = get_db()

    query = """
        SELECT
            users.id,
            users.full_name,
            users.email,
            users.account_type,
            users.created_at,
            GROUP_CONCAT(
                user_categories.category,
                '|||'
            ) AS categories
        FROM users
        JOIN user_categories
            ON users.id = user_categories.user_id
        WHERE users.account_type IN (
            'professional',
            'both'
        )
    """

    params = []

    if category:

        query += """
            AND users.id IN (
                SELECT user_id
                FROM user_categories
                WHERE category = ?
            )
        """

        params.append(category)

    if search:

        query += """
            AND (
                users.full_name LIKE ?
                OR users.id IN (
                    SELECT user_id
                    FROM user_categories
                    WHERE category LIKE ?
                )
            )
        """

        search_value = f"%{search}%"

        params.extend([
            search_value,
            search_value
        ])

    query += """
        GROUP BY
            users.id,
            users.full_name,
            users.email,
            users.account_type,
            users.created_at
        ORDER BY users.created_at DESC
    """

    professionals_list = conn.execute(
        query,
        params
    ).fetchall()

    conn.close()

    return render_template(
        "professionals.html",
        professionals=professionals_list,
        selected_category=category,
        search=search
    )


# =========================================================
# PROFESSIONAL PROFILE
# =========================================================

@app.route("/professional/<int:user_id>")
def professional_profile(user_id):

    conn = get_db()

    try:
        professional = conn.execute("""
            SELECT
                users.id,
                users.full_name,
                users.email,
                users.account_type,
                users.created_at,
                COALESCE(professional_profiles.professional_title, '') AS professional_title,
                COALESCE(professional_profiles.bio, '') AS bio,
                professional_profiles.hourly_rate,
                COALESCE(professional_profiles.location, '') AS location,
                COALESCE(professional_profiles.availability, 'available') AS availability,
                COALESCE(professional_profiles.experience, '') AS experience,
                COALESCE(professional_profiles.education, '') AS education,
                COALESCE(professional_profiles.certifications, '') AS certifications,
                COALESCE(professional_profiles.services, '') AS services,
                COALESCE(professional_profiles.languages, '') AS languages,
                COALESCE(
                    GROUP_CONCAT(user_categories.category, '|||'),
                    ''
                ) AS categories
            FROM users
            LEFT JOIN professional_profiles
                ON professional_profiles.user_id = users.id
            LEFT JOIN user_categories
                ON user_categories.user_id = users.id
            WHERE users.id = ?
              AND users.account_type IN ('professional', 'both')
            GROUP BY
                users.id,
                users.full_name,
                users.email,
                users.account_type,
                users.created_at,
                professional_profiles.professional_title,
                professional_profiles.bio,
                professional_profiles.hourly_rate,
                professional_profiles.location,
                professional_profiles.availability,
                professional_profiles.experience,
                professional_profiles.education,
                professional_profiles.certifications,
                professional_profiles.services,
                professional_profiles.languages
            LIMIT 1
        """, (user_id,)).fetchone()

        if not professional:
            flash("Professional not found.", "error")
            return redirect(url_for("professionals"))

        return render_template(
            "professional_profile.html",
            professional=professional
        )

    except sqlite3.Error as e:
        print("PROFESSIONAL PROFILE DATABASE ERROR:", e)
        flash("There was a problem loading this professional profile.", "error")
        return redirect(url_for("professionals"))

    finally:
        conn.close()


# =========================================================
# EDIT PROFESSIONAL PROFILE
# =========================================================

@app.route(
    "/professional/profile/edit",
    methods=["GET", "POST"]
)
@login_required
def edit_professional_profile():

    user_id = session["user_id"]

    conn = get_db()

    profile = conn.execute("""
        SELECT *
        FROM professional_profiles
        WHERE user_id = ?
    """, (
        user_id,
    )).fetchone()

    if request.method == "POST":

        professional_title = request.form.get(
            "professional_title",
            ""
        ).strip()

        bio = request.form.get(
            "bio",
            ""
        ).strip()

        hourly_rate = request.form.get(
            "hourly_rate",
            ""
        ).strip()

        location = request.form.get(
            "location",
            ""
        ).strip()

        availability = request.form.get(
            "availability",
            "available"
        ).strip()

        experience = request.form.get(
            "experience",
            ""
        ).strip()

        education = request.form.get(
            "education",
            ""
        ).strip()

        certifications = request.form.get(
            "certifications",
            ""
        ).strip()

        services = request.form.get(
            "services",
            ""
        ).strip()

        languages = request.form.get(
            "languages",
            ""
        ).strip()

        try:

            hourly_rate_value = (
                float(hourly_rate)
                if hourly_rate
                else None
            )

        except ValueError:

            hourly_rate_value = None

        conn.execute("""
            INSERT INTO professional_profiles (
                user_id,
                professional_title,
                bio,
                hourly_rate,
                location,
                availability,
                experience,
                education,
                certifications,
                services,
                languages,
                updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(user_id)
            DO UPDATE SET
                professional_title = excluded.professional_title,
                bio = excluded.bio,
                hourly_rate = excluded.hourly_rate,
                location = excluded.location,
                availability = excluded.availability,
                experience = excluded.experience,
                education = excluded.education,
                certifications = excluded.certifications,
                services = excluded.services,
                languages = excluded.languages,
                updated_at = CURRENT_TIMESTAMP
        """, (
            user_id,
            professional_title,
            bio,
            hourly_rate_value,
            location,
            availability,
            experience,
            education,
            certifications,
            services,
            languages
        ))

        conn.commit()
        conn.close()

        flash(
            "Professional profile updated successfully.",
            "success"
        )

        return redirect(
            url_for(
                "professional_profile",
                user_id=user_id
            )
        )

    if not profile:

        profile = {
            "professional_title": "",
            "bio": "",
            "hourly_rate": "",
            "location": "",
            "availability": "available",
            "experience": "",
            "education": "",
            "certifications": "",
            "services": "",
            "languages": ""
        }

    conn.close()

    return render_template(
        "professional_profile_edit.html",
        profile=profile
    )


# =========================================================
# POST PROJECT
# =========================================================

@app.route(
    "/projects/post",
    methods=["GET", "POST"]
)
@login_required
def post_project():

    if session.get("account_type") not in [
        "hire",
        "both"
    ]:

        flash(
            "Only hiring accounts can post projects.",
            "error"
        )

        return redirect(url_for("dashboard"))

    if request.method == "POST":

        title = request.form.get(
            "title",
            ""
        ).strip()

        description = request.form.get(
            "description",
            ""
        ).strip()

        category = request.form.get(
            "category",
            ""
        ).strip()

        experience_level = request.form.get(
            "experience_level",
            "any"
        ).strip()

        budget_type = request.form.get(
            "budget_type",
            "fixed"
        ).strip()

        budget_min = request.form.get(
            "budget_min",
            ""
        ).strip()

        budget_max = request.form.get(
            "budget_max",
            ""
        ).strip()

        deadline = request.form.get(
            "deadline",
            ""
        ).strip()

        if not title or not description or not category:

            flash(
                "Please complete all required project fields.",
                "error"
            )

            return redirect(
                url_for("post_project")
            )

        try:

            budget_min_value = float(budget_min)
            budget_max_value = float(budget_max)

        except ValueError:

            flash(
                "Please enter valid budget amounts.",
                "error"
            )

            return redirect(
                url_for("post_project")
            )

        if budget_min_value < 0 or budget_max_value < 0:

            flash(
                "Budget cannot be negative.",
                "error"
            )

            return redirect(
                url_for("post_project")
            )

        if budget_max_value < budget_min_value:

            flash(
                "Maximum budget cannot be lower than minimum budget.",
                "error"
            )

            return redirect(
                url_for("post_project")
            )

        conn = get_db()

        try:

            cursor = conn.execute("""
                INSERT INTO projects (
                    client_id,
                    title,
                    description,
                    category,
                    experience_level,
                    budget_type,
                    budget_min,
                    budget_max,
                    deadline
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                session["user_id"],
                title,
                description,
                category,
                experience_level,
                budget_type,
                budget_min_value,
                budget_max_value,
                deadline
            ))

            project_id = cursor.lastrowid

            conn.commit()

            flash(
                "Project posted successfully.",
                "success"
            )

            return redirect(
                url_for(
                    "project_details",
                    project_id=project_id
                )
            )

        except sqlite3.Error as e:

            conn.rollback()

            print("POST PROJECT DATABASE ERROR:", e)

            flash(
                "There was a problem posting the project.",
                "error"
            )

            return redirect(
                url_for("post_project")
            )

        finally:

            conn.close()

    return render_template("post_project.html")


@app.route("/project/<int:project_id>/complete", methods=["GET", "POST"])
def complete_project(project_id):
    if "user_id" not in session:
        return redirect(url_for("login"))

    conn = get_db()

    try:
        project = conn.execute("""
            SELECT
                projects.*,
                client.full_name AS client_name
            FROM projects
            JOIN users AS client
                ON projects.client_id = client.id
            WHERE projects.id = ?
        """, (project_id,)).fetchone()

        if not project:
            flash("Project not found.", "error")
            return redirect(url_for("dashboard"))

        accepted_proposal = conn.execute("""
            SELECT
                proposals.id,
                proposals.professional_id,
                users.full_name AS professional_name
            FROM proposals
            JOIN users
                ON proposals.professional_id = users.id
            WHERE proposals.project_id = ?
              AND proposals.status = 'accepted'
            LIMIT 1
        """, (project_id,)).fetchone()

        if not accepted_proposal:
            flash(
                "This project does not have an accepted professional.",
                "error"
            )
            return redirect(
                url_for(
                    "project_workspace",
                    project_id=project_id
                )
            )

        user_id = session["user_id"]

        if user_id != project["client_id"] and \
           user_id != accepted_proposal["professional_id"]:

            flash(
                "You do not have permission to complete this project.",
                "error"
            )

            return redirect(
                url_for(
                    "project_workspace",
                    project_id=project_id
                )
            )

        milestones = conn.execute("""
            SELECT *
            FROM milestones
            WHERE project_id = ?
            ORDER BY created_at ASC
        """, (project_id,)).fetchall()

        total_milestones = len(milestones)

        completed_milestones = sum(
            1
            for milestone in milestones
            if milestone["status"] == "completed"
        )

        paid_amount_row = conn.execute("""
            SELECT COALESCE(SUM(amount), 0)
            FROM payments
            WHERE project_id = ?
              AND status = 'paid'
        """, (project_id,)).fetchone()

        paid_amount = paid_amount_row[0] if paid_amount_row else 0

        if request.method == "POST":

            conn.execute("""
                UPDATE projects
                SET status = 'completed',
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (project_id,))

            conn.commit()

            flash(
                "Project marked as completed.",
                "success"
            )

            return redirect(
                url_for(
                    "project_review",
                    project_id=project_id
                )
            )

        return render_template(
            "project_completion.html",
            project=project,
            total_milestones=total_milestones,
            completed_milestones=completed_milestones,
            paid_amount=paid_amount
        )

    except sqlite3.Error as e:

        conn.rollback()

        print("PROJECT COMPLETION DATABASE ERROR:", e)

        flash(
            "There was a problem loading the project completion page.",
            "error"
        )

        return redirect(
            url_for(
                "project_workspace",
                project_id=project_id
            )
        )

    finally:
        conn.close()


# review page route
@app.route(
    "/project/<int:project_id>/review/submit",
    methods=["POST"]
)
def submit_project_review(project_id):
    if "user_id" not in session:
        return redirect(url_for("login"))

    user_id = session["user_id"]

    rating = request.form.get("rating", "").strip()
    review_text = request.form.get("review", "").strip()

    if not rating:
        flash(
            "Please select a rating.",
            "error"
        )

        return redirect(
            url_for(
                "project_review",
                project_id=project_id
            )
        )

    try:
        rating = int(rating)
    except ValueError:

        flash(
            "Invalid rating.",
            "error"
        )

        return redirect(
            url_for(
                "project_review",
                project_id=project_id
            )
        )

    if rating < 1 or rating > 5:

        flash(
            "Rating must be between 1 and 5 stars.",
            "error"
        )

        return redirect(
            url_for(
                "project_review",
                project_id=project_id
            )
        )

    if not review_text:

        flash(
            "Please write a review.",
            "error"
        )

        return redirect(
            url_for(
                "project_review",
                project_id=project_id
            )
        )

    if len(review_text) > 1000:

        flash(
            "Review must be 1000 characters or less.",
            "error"
        )

        return redirect(
            url_for(
                "project_review",
                project_id=project_id
            )
        )

    conn = get_db()

    try:

        project = conn.execute("""
            SELECT
                projects.id,
                projects.client_id,
                projects.status,
                proposals.professional_id
            FROM projects
            JOIN proposals
                ON proposals.project_id = projects.id
            WHERE projects.id = ?
              AND proposals.status = 'accepted'
            LIMIT 1
        """, (project_id,)).fetchone()

        if not project:

            flash(
                "Project or accepted professional not found.",
                "error"
            )

            return redirect(
                url_for(
                    "dashboard"
                )
            )

        if project["status"] != "completed":

            flash(
                "Reviews can only be submitted after project completion.",
                "error"
            )

            return redirect(
                url_for(
                    "project_workspace",
                    project_id=project_id
                )
            )

        client_id = project["client_id"]
        professional_id = project["professional_id"]

        if user_id == client_id:

            reviewee_id = professional_id

        elif user_id == professional_id:

            reviewee_id = client_id

        else:

            flash(
                "You are not a participant in this project.",
                "error"
            )

            return redirect(
                url_for(
                    "dashboard"
                )
            )

        existing_review = conn.execute("""
            SELECT id
            FROM reviews
            WHERE project_id = ?
              AND reviewer_id = ?
        """, (project_id, user_id)).fetchone()

        if existing_review:

            flash(
                "You have already reviewed this project.",
                "error"
            )

            return redirect(
                url_for(
                    "project_review",
                    project_id=project_id
                )
            )

        conn.execute("""
            INSERT INTO reviews (
                project_id,
                reviewer_id,
                reviewee_id,
                rating,
                review
            )
            VALUES (?, ?, ?, ?, ?)
        """, (
            project_id,
            user_id,
            reviewee_id,
            rating,
            review_text
        ))

        conn.commit()

        flash(
            "Your review has been submitted.",
            "success"
        )

        return redirect(
            url_for(
                "project_workspace",
                project_id=project_id
            )
        )

    except sqlite3.IntegrityError:

        conn.rollback()

        flash(
            "You have already reviewed this project.",
            "error"
        )

        return redirect(
            url_for(
                "project_review",
                project_id=project_id
            )
        )

    except sqlite3.Error as e:

        conn.rollback()

        print("REVIEW SUBMISSION DATABASE ERROR:", e)

        flash(
            "There was a problem submitting your review.",
            "error"
        )

        return redirect(
            url_for(
                "project_review",
                project_id=project_id
            )
        )

    finally:
        conn.close()

@app.route("/project/<int:project_id>/review")
def project_review(project_id):
    if "user_id" not in session:
        return redirect(url_for("login"))

    conn = get_db()

    try:
        project = conn.execute("""
            SELECT
                projects.*,
                client.full_name AS client_name
            FROM projects
            JOIN users AS client
                ON projects.client_id = client.id
            WHERE projects.id = ?
              AND projects.status = 'completed'
        """, (project_id,)).fetchone()

        if not project:
            flash(
                "This project is not available for review.",
                "error"
            )

            return redirect(
                url_for(
                    "dashboard"
                )
            )

        accepted_proposal = conn.execute("""
            SELECT
                professional_id,
                users.full_name AS professional_name
            FROM proposals
            JOIN users
                ON proposals.professional_id = users.id
            WHERE proposals.project_id = ?
              AND proposals.status = 'accepted'
            LIMIT 1
        """, (project_id,)).fetchone()

        if not accepted_proposal:
            flash(
                "No accepted professional was found for this project.",
                "error"
            )

            return redirect(
                url_for(
                    "project_workspace",
                    project_id=project_id
                )
            )

        user_id = session["user_id"]

        if user_id == project["client_id"]:
            reviewee_id = accepted_proposal["professional_id"]

        elif user_id == accepted_proposal["professional_id"]:
            reviewee_id = project["client_id"]

        else:
            flash(
                "You do not have access to this review.",
                "error"
            )

            return redirect(
                url_for(
                    "dashboard"
                )
            )

        existing_review = conn.execute("""
            SELECT *
            FROM reviews
            WHERE project_id = ?
              AND reviewer_id = ?
        """, (project_id, user_id)).fetchone()

        return render_template(
            "project_review.html",
            project=project,
            reviewee_id=reviewee_id,
            existing_review=existing_review
        )

    except sqlite3.Error as e:

        print("REVIEW PAGE DATABASE ERROR:", e)

        flash(
            "There was a problem loading the review page.",
            "error"
        )

        return redirect(
            url_for(
                "project_workspace",
                project_id=project_id
            )
        )

    finally:
        conn.close()


# =========================================================
# PROJECTS
# =========================================================

@app.route("/projects")
def projects():

    category = request.args.get(
        "category",
        ""
    ).strip()

    search = request.args.get(
        "search",
        ""
    ).strip()

    conn = get_db()

    query = """
        SELECT
            projects.*,
            users.full_name AS client_name,
            (
                SELECT COUNT(*)
                FROM proposals
                WHERE proposals.project_id = projects.id
            ) AS proposal_count
        FROM projects
        JOIN users
            ON projects.client_id = users.id
        WHERE projects.status = 'open'
    """

    params = []

    if category:

        query += """
            AND projects.category = ?
        """

        params.append(category)

    if search:

        query += """
            AND (
                projects.title LIKE ?
                OR projects.description LIKE ?
            )
        """

        search_value = f"%{search}%"

        params.extend([
            search_value,
            search_value
        ])

    query += """
        ORDER BY projects.created_at DESC
    """

    project_list = conn.execute(
        query,
        params
    ).fetchall()

    conn.close()

    return render_template(
        "projects.html",
        projects=project_list,
        selected_category=category,
        search=search
    )


# =========================================================
# PROJECT DETAILS
# =========================================================

@app.route("/project/<int:project_id>")
def project_details(project_id):

    conn = get_db()

    project = conn.execute("""
        SELECT
            projects.*,
            users.full_name AS client_name,
            users.email AS client_email
        FROM projects
        JOIN users
            ON projects.client_id = users.id
        WHERE projects.id = ?
    """, (
        project_id,
    )).fetchone()

    if not project:

        conn.close()

        flash(
            "Project not found.",
            "error"
        )

        return redirect(url_for("projects"))

    proposal_count = conn.execute("""
        SELECT COUNT(*)
        FROM proposals
        WHERE project_id = ?
    """, (
        project_id,
    )).fetchone()[0]

    existing_proposal = None

    if "user_id" in session:

        existing_proposal = conn.execute("""
            SELECT *
            FROM proposals
            WHERE project_id = ?
            AND professional_id = ?
        """, (
            project_id,
            session["user_id"]
        )).fetchone()

    conn.close()

    return render_template(
        "project_details.html",
        project=project,
        proposal_count=proposal_count,
        existing_proposal=existing_proposal
    )


# =========================================================
# SEND PROPOSAL
# =========================================================

@app.route(
    "/project/<int:project_id>/proposal",
    methods=["GET", "POST"]
)
@login_required
def send_proposal(project_id):

    if session.get("account_type") not in [
        "professional",
        "both"
    ]:

        flash(
            "Only professionals can submit proposals.",
            "error"
        )

        return redirect(
            url_for(
                "project_details",
                project_id=project_id
            )
        )

    conn = get_db()

    project = conn.execute("""
        SELECT *
        FROM projects
        WHERE id = ?
    """, (
        project_id,
    )).fetchone()

    if not project:

        conn.close()

        flash(
            "Project not found.",
            "error"
        )

        return redirect(url_for("projects"))

    if project["client_id"] == session["user_id"]:

        conn.close()

        flash(
            "You cannot submit a proposal to your own project.",
            "error"
        )

        return redirect(
            url_for(
                "project_details",
                project_id=project_id
            )
        )

    existing = conn.execute("""
        SELECT *
        FROM proposals
        WHERE project_id = ?
        AND professional_id = ?
    """, (
        project_id,
        session["user_id"]
    )).fetchone()

    if request.method == "POST":

        if existing:

            conn.close()

            flash(
                "You have already submitted a proposal for this project.",
                "error"
            )

            return redirect(
                url_for(
                    "project_details",
                    project_id=project_id
                )
            )

        proposed_amount = request.form.get(
            "proposed_amount",
            ""
        ).strip()

        delivery_days = request.form.get(
            "delivery_days",
            ""
        ).strip()

        message = request.form.get(
            "message",
            ""
        ).strip()

        if not proposed_amount or not message:

            conn.close()

            flash(
                "Please complete all required proposal fields.",
                "error"
            )

            return redirect(
                url_for(
                    "send_proposal",
                    project_id=project_id
                )
            )

        try:

            amount_value = float(proposed_amount)

            delivery_value = (
                int(delivery_days)
                if delivery_days
                else None
            )

        except ValueError:

            conn.close()

            flash(
                "Please enter valid proposal values.",
                "error"
            )

            return redirect(
                url_for(
                    "send_proposal",
                    project_id=project_id
                )
            )

        try:

            conn.execute("""
                INSERT INTO proposals (
                    project_id,
                    professional_id,
                    proposed_amount,
                    delivery_days,
                    message
                )
                VALUES (?, ?, ?, ?, ?)
            """, (
                project_id,
                session["user_id"],
                amount_value,
                delivery_value,
                message
            ))

            conn.commit()

            flash(
                "Proposal submitted successfully.",
                "success"
            )

            return redirect(
                url_for(
                    "project_details",
                    project_id=project_id
                )
            )

        except sqlite3.IntegrityError:

            conn.rollback()

            flash(
                "You have already submitted a proposal for this project.",
                "error"
            )

            return redirect(
                url_for(
                    "project_details",
                    project_id=project_id
                )
            )

        finally:

            conn.close()

    conn.close()

    return render_template(
        "send_proposal.html",
        project=project,
        existing_proposal=existing
    )


# =========================================================
# MY PROJECTS
# =========================================================

@app.route("/my-projects")
@login_required
def my_projects():

    user_id = session["user_id"]

    account_type = session.get(
        "account_type"
    )

    conn = get_db()

    client_projects = []

    submitted_proposals = []

    # -----------------------------------------------------
    # PROJECTS POSTED BY USER
    # -----------------------------------------------------

    if account_type in [
        "hire",
        "both"
    ]:

        client_projects = conn.execute("""
            SELECT
                projects.*,

                (
                    SELECT COUNT(*)
                    FROM proposals
                    WHERE proposals.project_id = projects.id
                ) AS proposal_count,

                (
                    SELECT COUNT(*)
                    FROM proposals
                    WHERE proposals.project_id = projects.id
                    AND proposals.status = 'accepted'
                ) AS accepted_proposal_count

            FROM projects

            WHERE projects.client_id = ?

            ORDER BY projects.created_at DESC

        """, (
            user_id,
        )).fetchall()

    # -----------------------------------------------------
    # PROPOSALS SUBMITTED BY USER
    # -----------------------------------------------------

    if account_type in [
        "professional",
        "both"
    ]:

        submitted_proposals = conn.execute("""
            SELECT

                proposals.*,

                projects.id AS project_id,
                projects.title AS project_title,
                projects.category AS project_category,
                projects.status AS project_status,

                users.full_name AS client_name

            FROM proposals

            JOIN projects
                ON proposals.project_id = projects.id

            JOIN users
                ON projects.client_id = users.id

            WHERE proposals.professional_id = ?

            ORDER BY proposals.created_at DESC

        """, (
            user_id,
        )).fetchall()

    conn.close()

    return render_template(
        "my_projects.html",
        account_type=account_type,
        client_projects=client_projects,
        submitted_proposals=submitted_proposals
    )


# =========================================================
# PROJECT PROPOSALS
# =========================================================

@app.route(
    "/project/<int:project_id>/proposals"
)
@login_required
def project_proposals(project_id):

    conn = get_db()

    project = conn.execute("""
        SELECT *
        FROM projects
        WHERE id = ?
    """, (
        project_id,
    )).fetchone()

    if not project:

        conn.close()

        flash(
            "Project not found.",
            "error"
        )

        return redirect(url_for("my_projects"))

    if project["client_id"] != session["user_id"]:

        conn.close()

        flash(
            "You are not allowed to view these proposals.",
            "error"
        )

        return redirect(url_for("my_projects"))

    proposals = conn.execute("""
        SELECT
            proposals.*,
            users.full_name AS professional_name,
            users.email AS professional_email
        FROM proposals
        JOIN users
            ON proposals.professional_id = users.id
        WHERE proposals.project_id = ?
        ORDER BY
            CASE
                WHEN proposals.status = 'pending'
                THEN 1
                WHEN proposals.status = 'accepted'
                THEN 2
                ELSE 3
            END,
            proposals.created_at DESC
    """, (
        project_id,
    )).fetchall()

    conn.close()

    return render_template(
        "hire_proposals.html",
        project=project,
        proposals=proposals
    )


# =========================================================
# PROPOSAL DETAILS
# =========================================================

@app.route(
    "/project/<int:project_id>/proposals/<int:proposal_id>"
)
@login_required
def proposal_details(
    project_id,
    proposal_id
):

    conn = get_db()

    proposal = conn.execute("""
        SELECT
            proposals.*,

            projects.title AS project_title,
            projects.description AS project_description,
            projects.category AS project_category,
            projects.client_id,
            projects.budget_type,
            projects.budget_min,
            projects.budget_max,
            projects.deadline,
            projects.status AS project_status,

            professional.full_name AS professional_name,
            professional.email AS professional_email,

            client.full_name AS client_name,
            client.email AS client_email

        FROM proposals

        JOIN projects
            ON proposals.project_id = projects.id

        JOIN users AS professional
            ON proposals.professional_id = professional.id

        JOIN users AS client
            ON projects.client_id = client.id

        WHERE proposals.id = ?
        AND proposals.project_id = ?

    """, (
        proposal_id,
        project_id
    )).fetchone()

    if not proposal:

        conn.close()

        flash(
            "Proposal not found.",
            "error"
        )

        return redirect(url_for("my_projects"))

    if (
        proposal["client_id"] != session["user_id"]
        and proposal["professional_id"] != session["user_id"]
    ):

        conn.close()

        flash(
            "You are not allowed to view this proposal.",
            "error"
        )

        return redirect(url_for("dashboard"))

    conn.close()

    return render_template(
        "proposal_details.html",
        proposal=proposal
    )


# =========================================================
# ACCEPT PROPOSAL
# =========================================================

@app.route(
    "/project/<int:project_id>/proposals/<int:proposal_id>/accept",
    methods=["POST"]
)
@login_required
def accept_proposal(
    project_id,
    proposal_id
):

    conn = get_db()

    try:

        proposal = conn.execute("""
            SELECT
                proposals.id,
                proposals.status,
                projects.client_id
            FROM proposals

            JOIN projects
                ON proposals.project_id = projects.id

            WHERE proposals.id = ?
            AND proposals.project_id = ?

        """, (
            proposal_id,
            project_id
        )).fetchone()

        if not proposal:

            flash(
                "Proposal not found.",
                "error"
            )

            return redirect(
                url_for(
                    "my_projects"
                )
            )

        if proposal["client_id"] != session["user_id"]:

            flash(
                "You are not allowed to accept this proposal.",
                "error"
            )

            return redirect(
                url_for(
                    "proposal_details",
                    project_id=project_id,
                    proposal_id=proposal_id
                )
            )

        if proposal["status"] != "pending":

            flash(
                "This proposal is no longer pending.",
                "error"
            )

            return redirect(
                url_for(
                    "proposal_details",
                    project_id=project_id,
                    proposal_id=proposal_id
                )
            )

        conn.execute("""
            UPDATE proposals

            SET status = 'rejected',
                updated_at = CURRENT_TIMESTAMP

            WHERE project_id = ?
            AND status = 'pending'
            AND id != ?

        """, (
            project_id,
            proposal_id
        ))

        conn.execute("""
            UPDATE proposals

            SET status = 'accepted',
                updated_at = CURRENT_TIMESTAMP

            WHERE id = ?

        """, (
            proposal_id,
        ))

        conn.commit()

        flash(
            "Proposal accepted. The project workspace is now available.",
            "success"
        )

        return redirect(
            url_for(
                "proposal_details",
                project_id=project_id,
                proposal_id=proposal_id
            )
        )

    except sqlite3.Error as e:

        conn.rollback()

        print(
            "ACCEPT PROPOSAL DATABASE ERROR:",
            e
        )

        flash(
            "There was a problem accepting the proposal.",
            "error"
        )

        return redirect(
            url_for(
                "proposal_details",
                project_id=project_id,
                proposal_id=proposal_id
            )
        )

    finally:

        conn.close()


# =========================================================
# REJECT PROPOSAL
# =========================================================

@app.route(
    "/project/<int:project_id>/proposals/<int:proposal_id>/reject",
    methods=["POST"]
)
@login_required
def reject_proposal(
    project_id,
    proposal_id
):

    conn = get_db()

    try:

        proposal = conn.execute("""
            SELECT
                proposals.id,
                proposals.status,
                projects.client_id

            FROM proposals

            JOIN projects
                ON proposals.project_id = projects.id

            WHERE proposals.id = ?
            AND proposals.project_id = ?

        """, (
            proposal_id,
            project_id
        )).fetchone()

        if not proposal:

            flash(
                "Proposal not found.",
                "error"
            )

            return redirect(
                url_for("my_projects")
            )

        if proposal["client_id"] != session["user_id"]:

            flash(
                "You are not allowed to reject this proposal.",
                "error"
            )

            return redirect(
                url_for(
                    "proposal_details",
                    project_id=project_id,
                    proposal_id=proposal_id
                )
            )

        if proposal["status"] != "pending":

            flash(
                "This proposal is no longer pending.",
                "error"
            )

            return redirect(
                url_for(
                    "proposal_details",
                    project_id=project_id,
                    proposal_id=proposal_id
                )
            )

        conn.execute("""
            UPDATE proposals

            SET status = 'rejected',
                updated_at = CURRENT_TIMESTAMP

            WHERE id = ?

        """, (
            proposal_id,
        ))

        conn.commit()

        flash(
            "Proposal rejected.",
            "success"
        )

        return redirect(
            url_for(
                "proposal_details",
                project_id=project_id,
                proposal_id=proposal_id
            )
        )

    except sqlite3.Error as e:

        conn.rollback()

        print(
            "REJECT PROPOSAL DATABASE ERROR:",
            e
        )

        flash(
            "There was a problem rejecting the proposal.",
            "error"
        )

        return redirect(
            url_for(
                "proposal_details",
                project_id=project_id,
                proposal_id=proposal_id
            )
        )

    finally:

        conn.close()


# =========================================================
# PROJECT WORKSPACE
# =========================================================

@app.route(
    "/project/<int:project_id>/workspace"
)
@login_required
def project_workspace(project_id):

    user_id = session["user_id"]

    conn = get_db()

    try:

        workspace = conn.execute("""
            SELECT

                projects.id AS project_id,
                projects.title,
                projects.description,
                projects.category,
                projects.experience_level,
                projects.budget_type,
                projects.budget_min,
                projects.budget_max,
                projects.deadline,
                projects.status AS project_status,
                projects.created_at,

                client.id AS client_id,
                client.full_name AS client_name,
                client.email AS client_email,

                professional.id AS professional_id,
                professional.full_name AS professional_name,
                professional.email AS professional_email,

                proposals.id AS proposal_id,
                proposals.proposed_amount,
                proposals.delivery_days,
                proposals.message AS proposal_message,
                proposals.status AS proposal_status,
                proposals.created_at AS proposal_created_at

            FROM projects

            JOIN proposals
                ON proposals.project_id = projects.id

            JOIN users AS client
                ON projects.client_id = client.id

            JOIN users AS professional
                ON proposals.professional_id = professional.id

            WHERE projects.id = ?

            AND proposals.status = 'accepted'

            AND (
                projects.client_id = ?
                OR proposals.professional_id = ?
            )

            LIMIT 1

        """, (
            project_id,
            user_id,
            user_id
        )).fetchone()

        if not workspace:

            flash(
                "You do not have access to this project workspace.",
                "error"
            )

            return redirect(
                url_for("dashboard")
            )

        message_count = conn.execute("""
            SELECT COUNT(*)
            FROM messages
            WHERE project_id = ?
        """, (
            project_id,
        )).fetchone()[0]

        return render_template(
            "project_workspace.html",
            workspace=workspace,
            message_count=message_count
        )

    except sqlite3.Error as e:

        print(
            "WORKSPACE DATABASE ERROR:",
            e
        )

        flash(
            "There was a problem loading the project workspace.",
            "error"
        )

        return redirect(
            url_for("dashboard")
        )

    finally:

        conn.close()


# =========================================================
# PROJECT MESSAGES
# =========================================================

@app.route(
    "/project/<int:project_id>/messages",
    methods=["GET", "POST"]
)
@login_required
def project_messages(project_id):

    user_id = session["user_id"]

    conn = get_db()

    try:

        workspace = conn.execute("""
            SELECT

                projects.id AS project_id,
                projects.title,
                projects.client_id,
                proposals.professional_id

            FROM projects

            JOIN proposals
                ON proposals.project_id = projects.id

            WHERE projects.id = ?

            AND proposals.status = 'accepted'

            AND (
                projects.client_id = ?
                OR proposals.professional_id = ?
            )

            LIMIT 1

        """, (
            project_id,
            user_id,
            user_id
        )).fetchone()

        if not workspace:

            flash(
                "You do not have access to these messages.",
                "error"
            )

            return redirect(
                url_for("dashboard")
            )

        # -------------------------------------------------
        # SEND MESSAGE
        # -------------------------------------------------

        if request.method == "POST":

            message = request.form.get(
                "message",
                ""
            ).strip()

            if not message:

                flash(
                    "Please enter a message.",
                    "error"
                )

                return redirect(
                    url_for(
                        "project_messages",
                        project_id=project_id
                    )
                )

            if user_id == workspace["client_id"]:

                receiver_id = workspace[
                    "professional_id"
                ]

            else:

                receiver_id = workspace[
                    "client_id"
                ]

            conn.execute("""
                INSERT INTO messages (
                    project_id,
                    sender_id,
                    receiver_id,
                    message
                )

                VALUES (?, ?, ?, ?)

            """, (
                project_id,
                user_id,
                receiver_id,
                message
            ))

            conn.commit()

            return redirect(
                url_for(
                    "project_messages",
                    project_id=project_id
                )
            )

        # -------------------------------------------------
        # MARK RECEIVED MESSAGES AS READ
        # -------------------------------------------------

        conn.execute("""
            UPDATE messages

            SET is_read = 1

            WHERE project_id = ?

            AND receiver_id = ?

        """, (
            project_id,
            user_id
        ))

        conn.commit()

        # -------------------------------------------------
        # LOAD MESSAGES
        # -------------------------------------------------

        messages = conn.execute("""
            SELECT

                messages.id,
                messages.message,
                messages.created_at,
                messages.sender_id,
                messages.receiver_id,
                messages.is_read,

                users.full_name AS sender_name

            FROM messages

            JOIN users
                ON messages.sender_id = users.id

            WHERE messages.project_id = ?

            ORDER BY messages.created_at ASC

        """, (
            project_id,
        )).fetchall()

        current_user = conn.execute("""
            SELECT
                id,
                full_name
            FROM users
            WHERE id = ?
        """, (
            user_id,
        )).fetchone()

        return render_template(
            "messages.html",
            workspace=workspace,
            messages=messages,
            current_user=current_user
        )

    except sqlite3.Error as e:

        conn.rollback()

        print(
            "MESSAGE DATABASE ERROR:",
            e
        )

        flash(
            "There was a problem loading the project messages.",
            "error"
        )

        return redirect(
            url_for(
                "project_workspace",
                project_id=project_id
            )
        )

    finally:

        conn.close()

# =========================================================
# PROFESSIONAL REVIEWS
# =========================================================

@app.route("/professional/<int:user_id>/reviews")
def professional_reviews(user_id):

    conn = get_db()

    try:

        professional = conn.execute("""
            SELECT
                users.id,
                users.full_name,
                users.account_type,
                professional_profiles.professional_title,
                professional_profiles.location
            FROM users
            LEFT JOIN professional_profiles
                ON users.id = professional_profiles.user_id
            WHERE users.id = ?
              AND users.account_type IN ('professional', 'both')
        """, (user_id,)).fetchone()

        if not professional:

            flash(
                "Professional profile not found.",
                "error"
            )

            return redirect(
                url_for("professionals")
            )

        reviews = conn.execute("""
            SELECT
                reviews.id,
                reviews.rating,
                reviews.review,
                reviews.created_at,
                users.id AS reviewer_id,
                users.full_name AS reviewer_name,
                projects.id AS project_id,
                projects.title AS project_title
            FROM reviews
            JOIN users
                ON reviews.reviewer_id = users.id
            JOIN projects
                ON reviews.project_id = projects.id
            WHERE reviews.reviewee_id = ?
            ORDER BY reviews.created_at DESC
        """, (user_id,)).fetchall()

        stats = conn.execute("""
            SELECT
                COUNT(*) AS review_count,
                COALESCE(AVG(rating), 0) AS average_rating,
                COALESCE(SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END), 0) AS five_star,
                COALESCE(SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END), 0) AS four_star,
                COALESCE(SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END), 0) AS three_star,
                COALESCE(SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END), 0) AS two_star,
                COALESCE(SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END), 0) AS one_star
            FROM reviews
            WHERE reviewee_id = ?
        """, (user_id,)).fetchone()

        return render_template(
            "professional_reviews.html",
            professional=professional,
            reviews=reviews,
            stats=stats
        )

    except sqlite3.Error as e:

        print(
            "PROFESSIONAL REVIEWS DATABASE ERROR:",
            e
        )

        flash(
            "There was a problem loading the reviews.",
            "error"
        )

        return redirect(
            url_for("professionals")
        )

    finally:

        conn.close()


# =========================================================
# MY REVIEWS
# =========================================================

@app.route("/my-reviews")
def my_reviews():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    user_id = session["user_id"]

    conn = get_db()

    try:

        received_reviews = conn.execute("""
            SELECT
                reviews.id,
                reviews.rating,
                reviews.review,
                reviews.created_at,
                users.id AS reviewer_id,
                users.full_name AS reviewer_name,
                projects.id AS project_id,
                projects.title AS project_title
            FROM reviews
            JOIN users
                ON reviews.reviewer_id = users.id
            JOIN projects
                ON reviews.project_id = projects.id
            WHERE reviews.reviewee_id = ?
            ORDER BY reviews.created_at DESC
        """, (user_id,)).fetchall()

        given_reviews = conn.execute("""
            SELECT
                reviews.id,
                reviews.rating,
                reviews.review,
                reviews.created_at,
                users.id AS reviewee_id,
                users.full_name AS reviewee_name,
                projects.id AS project_id,
                projects.title AS project_title
            FROM reviews
            JOIN users
                ON reviews.reviewee_id = users.id
            JOIN projects
                ON reviews.project_id = projects.id
            WHERE reviews.reviewer_id = ?
            ORDER BY reviews.created_at DESC
        """, (user_id,)).fetchall()

        received_stats = conn.execute("""
            SELECT
                COUNT(*) AS review_count,
                COALESCE(AVG(rating), 0) AS average_rating
            FROM reviews
            WHERE reviewee_id = ?
        """, (user_id,)).fetchone()

        given_stats = conn.execute("""
            SELECT
                COUNT(*) AS review_count,
                COALESCE(AVG(rating), 0) AS average_rating
            FROM reviews
            WHERE reviewer_id = ?
        """, (user_id,)).fetchone()

        return render_template(
            "my_reviews.html",
            received_reviews=received_reviews,
            given_reviews=given_reviews,
            received_stats=received_stats,
            given_stats=given_stats
        )

    except sqlite3.Error as e:

        print(
            "MY REVIEWS DATABASE ERROR:",
            e
        )

        flash(
            "There was a problem loading your reviews.",
            "error"
        )

        return redirect(
            url_for("dashboard")
        )

    finally:

        conn.close()

# =========================================================
# RUN APPLICATION
# =========================================================

if __name__ == "__main__":

    init_db()

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )